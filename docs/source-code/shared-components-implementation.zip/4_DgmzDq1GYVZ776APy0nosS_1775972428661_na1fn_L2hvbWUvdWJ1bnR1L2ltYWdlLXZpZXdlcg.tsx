
import React from 'react';
import LightGallery from 'lightgallery/react';
import lgZoom from 'lightgallery/plugins/zoom';
import lgThumbnail from 'lightgallery/plugins/thumbnail';
import lgFullscreen from 'lightgallery/plugins/fullscreen';
import { motion } from 'framer-motion';
import { ImageViewerProps } from './types';

import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lg-zoom.css';
import 'lightgallery/css/lg-thumbnail.css';
import 'lightgallery/css/lg-fullscreen.css';
import './image-viewer.css';

const ImageViewer: React.FC<ImageViewerProps> = ({ 
  images, 
  concept, 
  showThumbnails = true, 
  showZoom = true, 
  showFullscreen = true, 
  allow360 = false, 
  initialIndex = 0,
  motionProps 
}) => {
  const plugins = [];
  if (showThumbnails) plugins.push(lgThumbnail);
  if (showZoom) plugins.push(lgZoom);
  if (showFullscreen) plugins.push(lgFullscreen);

  // A placeholder for the 360 view feature
  const render360Placeholder = () => {
    if (!allow360) return null;
    return (
      <div className="flex items-center justify-center w-full h-full bg-gray-200">
        <p className="text-gray-500">360° view not available</p>
      </div>
    );
  };

  return (
    <motion.div 
      className={`image-viewer-container ${concept}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
      {...motionProps}
    >
      <LightGallery
        plugins={plugins}
        dynamic={true}
        dynamicEl={images}
        index={initialIndex}
        speed={800}
        easing="cubic-bezier(0.4, 0, 0.2, 1)"
        download={false}
        counter={false}
        // Add more lightGallery options here to match the luxury design
      />
      {render360Placeholder()}
    </motion.div>
  );
};

export default ImageViewer;
