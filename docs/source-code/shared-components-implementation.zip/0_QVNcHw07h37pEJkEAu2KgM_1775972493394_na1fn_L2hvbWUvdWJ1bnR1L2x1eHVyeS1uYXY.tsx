```typescript
//-*- typescript -*-
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

// --- THEMES AND TYPES ---

export type Concept = 'concept1' | 'concept2' | 'concept3' | 'concept4' | 'concept5' | 'concept6' | 'concept7' | 'concept8' | 'concept9' | 'concept10';

export interface NavLink {
  href: string;
  label: string;
}

export interface LuxuryNavProps {
  concept: Concept;
  logo: React.ReactNode;
  links: NavLink[];
}

export interface ConceptTheme {
  background: string;
  text: string;
  highlight: string;
  backdropBlur: string;
}

export const themes: Record<Concept, ConceptTheme> = {
  concept1: { background: 'rgba(255, 255, 255, 0.1)', text: '#FFFFFF', highlight: '#F0E68C', backdropBlur: 'blur(10px)' },
  concept2: { background: 'rgba(0, 0, 0, 0.2)', text: '#E0E0E0', highlight: '#ADD8E6', backdropBlur: 'blur(12px)' },
  concept3: { background: 'rgba(25, 25, 112, 0.1)', text: '#FFFFFF', highlight: '#FFD700', backdropBlur: 'blur(8px)' },
  concept4: { background: 'rgba(139, 0, 0, 0.1)', text: '#FFFFFF', highlight: '#FFA07A', backdropBlur: 'blur(15px)' },
  concept5: { background: 'rgba(0, 100, 0, 0.1)', text: '#FFFFFF', highlight: '#98FB98', backdropBlur: 'blur(10px)' },
  concept6: { background: 'rgba(255, 255, 255, 0.2)', text: '#000000', highlight: '#808080', backdropBlur: 'blur(5px)' },
  concept7: { background: 'rgba(75, 0, 130, 0.1)', text: '#FFFFFF', highlight: '#EE82EE', backdropBlur: 'blur(12px)' },
  concept8: { background: 'rgba(255, 140, 0, 0.1)', text: '#FFFFFF', highlight: '#FFFF00', backdropBlur: 'blur(10px)' },
  concept9: { background: 'rgba(0, 128, 128, 0.1)', text: '#FFFFFF', highlight: '#AFEEEE', backdropBlur: 'blur(8px)' },
  concept10: { background: 'rgba(128, 0, 128, 0.1)', text: '#FFFFFF', highlight: '#DA70D6', backdropBlur: 'blur(14px)' },
};

// --- COMPONENT IMPLEMENTATION ---

const LuxuryNav: React.FC<LuxuryNavProps> = ({ concept, logo, links }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSticky, setIsSticky] = useState(false);
  const theme = themes[concept];

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navVariants = {
    initial: { y: -100, opacity: 0 },
    animate: { y: 0, opacity: 1, transition: { duration: 0.8, ease: [0.6, 0.01, -0.05, 0.9] } },
  };

  const mobileMenuVariants = {
    hidden: { opacity: 0, transition: { duration: 0.6, ease: 'easeInOut' } },
    visible: { opacity: 1, transition: { duration: 0.6, ease: 'easeInOut' } },
  };

  return (
    <motion.nav
      variants={navVariants}
      initial="initial"
      animate="animate"
      style={{
        backgroundColor: isSticky ? theme.background : 'transparent',
        backdropFilter: isSticky ? theme.backdropBlur : 'none',
        color: theme.text,
      }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ease-in-out font-light tracking-[0.15em] uppercase`}
      aria-label="Main navigation"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          <div className="flex-shrink-0">{logo}</div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {links.map((link, index) => (
                <motion.a
                  key={index}
                  href={link.href}
                  className="px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300"
                  whileHover={{ color: theme.highlight, transition: { duration: 0.3 } }}
                >
                  {link.label}
                </motion.a>
              ))}
            </div>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md focus:outline-none"
              aria-controls="mobile-menu"
              aria-expanded={isOpen}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-menu"
            variants={mobileMenuVariants}
            initial="hidden"
            animate="visible"
            exit="hidden"
            className="md:hidden"
            style={{ backgroundColor: theme.background, backdropFilter: theme.backdropBlur }}
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {links.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="block px-3 py-2 rounded-md text-base font-medium"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default LuxuryNav;
```
