import { motion } from 'framer-motion';
import { Twitter, Instagram, Facebook, Linkedin } from 'lucide-react';
import clsx from 'clsx';

// THEMES
const themes = {
  vault: {
    background: 'bg-gray-900',
    text: 'text-gray-300',
    heading: 'text-white',
    link: 'text-gray-400 hover:text-white',
    border: 'border-gray-700',
    inputBg: 'bg-gray-800',
    inputText: 'text-white',
    buttonBg: 'bg-white',
    buttonText: 'text-black',
  },
  observatory: {
    background: 'bg-blue-900',
    text: 'text-blue-200',
    heading: 'text-white',
    link: 'text-blue-300 hover:text-white',
    border: 'border-blue-700',
    inputBg: 'bg-blue-800',
    inputText: 'text-white',
    buttonBg: 'bg-white',
    buttonText: 'text-blue-900',
  },
  gallery: {
    background: 'bg-white',
    text: 'text-gray-600',
    heading: 'text-black',
    link: 'text-gray-500 hover:text-black',
    border: 'border-gray-200',
    inputBg: 'bg-gray-100',
    inputText: 'text-black',
    buttonBg: 'bg-black',
    buttonText: 'text-white',
  },
  atelier: {
    background: 'bg-stone-100',
    text: 'text-stone-600',
    heading: 'text-stone-800',
    link: 'text-stone-500 hover:text-stone-900',
    border: 'border-stone-200',
    inputBg: 'bg-white',
    inputText: 'text-black',
    buttonBg: 'bg-stone-800',
    buttonText: 'text-white',
  },
  salon: {
    background: 'bg-rose-50',
    text: 'text-rose-600',
    heading: 'text-rose-800',
    link: 'text-rose-500 hover:text-rose-900',
    border: 'border-rose-200',
    inputBg: 'bg-white',
    inputText: 'text-black',
    buttonBg: 'bg-rose-800',
    buttonText: 'text-white',
  },
  archive: {
    background: 'bg-yellow-50',
    text: 'text-yellow-700',
    heading: 'text-yellow-900',
    link: 'text-yellow-600 hover:text-yellow-900',
    border: 'border-yellow-200',
    inputBg: 'bg-white',
    inputText: 'text-black',
    buttonBg: 'bg-yellow-900',
    buttonText: 'text-white',
  },
  minimal: {
    background: 'bg-white',
    text: 'text-gray-500',
    heading: 'text-black',
    link: 'text-gray-500 hover:text-black',
    border: 'border-gray-200',
    inputBg: 'bg-gray-100',
    inputText: 'text-black',
    buttonBg: 'bg-black',
    buttonText: 'text-white',
  },
  theater: {
    background: 'bg-red-900',
    text: 'text-red-200',
    heading: 'text-white',
    link: 'text-red-300 hover:text-white',
    border: 'border-red-700',
    inputBg: 'bg-red-800',
    inputText: 'text-white',
    buttonBg: 'bg-white',
    buttonText: 'text-red-900',
  },
  marketplace: {
    background: 'bg-green-900',
    text: 'text-green-200',
    heading: 'text-white',
    link: 'text-green-300 hover:text-white',
    border: 'border-green-700',
    inputBg: 'bg-green-800',
    inputText: 'text-white',
    buttonBg: 'bg-white',
    buttonText: 'text-green-900',
  },
  maison: {
    background: 'bg-purple-900',
    text: 'text-purple-200',
    heading: 'text-white',
    link: 'text-purple-300 hover:text-white',
    border: 'border-purple-700',
    inputBg: 'bg-purple-800',
    inputText: 'text-white',
    buttonBg: 'bg-white',
    buttonText: 'text-purple-900',
  },
};

// PROPS
interface LuxuryFooterProps {
  concept: keyof typeof themes;
  linkSections: {
    title: string;
    links: {
      label: string;
      href: string;
    }[];
  }[];
  socialLinks: {
    platform: 'twitter' | 'instagram' | 'facebook' | 'linkedin';
    href: string;
  }[];
  showNewsletter?: boolean;
  newsletterTitle?: string;
  newsletterPlaceholder?: string;
  newsletterButtonText?: string;
}

const SocialIcon = ({ platform, href, className }: { platform: string; href: string; className: string }) => {
  const icons: { [key: string]: React.ComponentType<any> } = {
    twitter: Twitter,
    instagram: Instagram,
    facebook: Facebook,
    linkedin: Linkedin,
  };
  const Icon = icons[platform];
  return Icon ? <a href={href} target="_blank" rel="noopener noreferrer" className={className}><Icon /></a> : null;
};

// COMPONENT
export default function LuxuryFooter({
  concept,
  linkSections,
  socialLinks,
  showNewsletter = true,
  newsletterTitle = 'Subscribe to our newsletter',
  newsletterPlaceholder = 'Enter your email',
  newsletterButtonText = 'Subscribe',
}: LuxuryFooterProps) {
  const theme = themes[concept];

  return (
    <motion.footer
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: [0.6, 0.01, -0.05, 0.9] }}
      className={clsx('py-[10vh]', theme.background, theme.text)}
    >
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {linkSections.map((section, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: 'easeOut' }}
            >
              <h4 className={clsx('font-semibold uppercase tracking-[0.15em] mb-4', theme.heading)}>{section.title}</h4>
              <ul>
                {section.links.map((link, j) => (
                  <li key={j} className="mb-2">
                    <a href={link.href} className={clsx('font-light', theme.link)}>{link.label}</a>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}

          {showNewsletter && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4, ease: 'easeOut' }}
              className="lg:col-span-2"
            >
              <h4 className={clsx('font-semibold uppercase tracking-[0.15em] mb-4', theme.heading)}>{newsletterTitle}</h4>
              <form className="flex">
                <input
                  type="email"
                  placeholder={newsletterPlaceholder}
                  className={clsx('w-full px-4 py-2 font-light', theme.inputBg, theme.inputText)}
                  aria-label="Email for newsletter"
                />
                <button type="submit" className={clsx('px-6 py-2 font-semibold', theme.buttonBg, theme.buttonText)}>
                  {newsletterButtonText}
                </button>
              </form>
            </motion.div>
          )}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className={clsx('mt-16 pt-8 flex flex-col md:flex-row justify-between items-center', `border-t ${theme.border}`)}
        >
          <p className="font-light text-sm mb-4 md:mb-0">&copy; {new Date().getFullYear()} Vault-Maison. All Rights Reserved.</p>
          <div className="flex space-x-4">
            {socialLinks.map((social, i) => (
              <SocialIcon key={i} platform={social.platform} href={social.href} className={clsx('w-6 h-6', theme.link)} />
            ))}
          </div>
        </motion.div>
      </div>
    </motion.footer>
  );
}
