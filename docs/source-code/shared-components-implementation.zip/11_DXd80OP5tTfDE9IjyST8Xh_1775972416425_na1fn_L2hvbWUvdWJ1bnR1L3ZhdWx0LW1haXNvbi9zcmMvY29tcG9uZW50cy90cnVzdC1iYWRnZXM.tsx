import React from 'react';
import { motion } from 'framer-motion';
import { Gem, ShieldCheck, Truck, Lock } from 'lucide-react';
import type { TrustBadgeProps, Concept } from './trust-badges.types';

// --- Data for the Badges ---
const trustBadges = [
  { id: 'gia', icon: Gem, text: 'GIA Certified' },
  { id: 'guarantee', icon: ShieldCheck, text: 'Money-Back Guarantee' },
  { id: 'shipping', icon: Truck, text: 'Insured Shipping' },
  { id: 'payment', icon: Lock, text: 'Secure Payment' },
];

// --- Theming for Different Concepts ---
// Each concept has a unique color palette for icons and text.
const themes: Record<Concept, { iconColor: string; textColor: string }> = {
  classic: { iconColor: 'text-gray-700', textColor: 'text-gray-600' },
  modern: { iconColor: 'text-blue-500', textColor: 'text-gray-800' },
  vintage: { iconColor: 'text-amber-800', textColor: 'text-stone-700' },
  'art-deco': { iconColor: 'text-yellow-400', textColor: 'text-gray-200' },
  minimalist: { iconColor: 'text-gray-400', textColor: 'text-gray-500' },
  'avant-garde': { iconColor: 'text-red-600', textColor: 'text-black' },
  bohemian: { iconColor: 'text-emerald-700', textColor: 'text-orange-900' },
  celestial: { iconColor: 'text-indigo-400', textColor: 'text-purple-300' },
  geometric: { iconColor: 'text-pink-600', textColor: 'text-gray-700' },
  floral: { iconColor: 'text-rose-500', textColor: 'text-green-800' },
};

/**
 * TrustBadges Component
 * Displays a set of trust-building badges (e.g., GIA, Insured Shipping).
 * The visual appearance is determined by the `concept` prop.
 */
const TrustBadges: React.FC<TrustBadgeProps> = ({ concept = 'classic' }) => {
  const currentTheme = themes[concept];

  // --- Animation Variants for Framer Motion ---
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        duration: 0.6,
        ease: 'easeOut',
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8, // Luxury feel with a slightly longer duration
        ease: [0.43, 0.13, 0.23, 0.96], // Custom bezier for a luxury easing
      },
    },
  };

  return (
    <section className="w-full bg-transparent">
      <motion.div
        className="flex flex-wrap justify-center items-start gap-8 md:gap-16 py-12 md:py-[10vh] px-4"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.5 }}
        aria-label="Trust and certification badges"
      >
        {trustBadges.map((badge) => (
          <motion.div
            key={badge.id}
            className="flex flex-col items-center text-center w-24"
            variants={itemVariants}
            role="group"
            aria-label={badge.text}
          >
            <badge.icon
              className={`w-12 h-12 mb-3 ${currentTheme.iconColor}`}
              aria-hidden="true"
              strokeWidth={1.5} // Thinner stroke for a more refined look
            />
            <p
              className={`font-light text-xs tracking-[0.15em] uppercase ${currentTheme.textColor}`}
            >
              {badge.text}
            </p>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
};

export default TrustBadges;
