import React, { useState, useMemo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Define the concept themes
type Concept = 'classic' | 'modern' | 'minimalist' | 'avant-garde' | 'art-deco' | 'bohemian' | 'industrial' | 'coastal' | 'vintage' | 'tech';

// Define the product data structure
interface Product {
  id: string;
  name: string;
  price: number;
  imageUrl: string;
  category: string;
}

// Define the component props
interface ProductGridProps {
  concept: Concept;
  products: Product[];
  layout: '3-col' | 'masonry' | 'table' | 'single';
  itemsPerPage?: number;
  isLoading?: boolean;
}

const ProductCard: React.FC<{ product: Product }> = ({ product }) => (
  <motion.div
    layout
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    transition={{ duration: 0.8, ease: [0.6, 0.01, -0.05, 0.9] }}
    className="w-full"
    role="group"
    aria-labelledby={`product-name-${product.id}`}
  >
    <div className="overflow-hidden">
        <motion.img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-auto" 
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.6, ease: [0.6, 0.01, -0.05, 0.9] }}
        />
    </div>
    <h3 id={`product-name-${product.id}`} className="font-normal text-lg tracking-[0.15em] uppercase mt-4">{product.name}</h3>
    <p className="font-light text-base">${product.price.toFixed(2)}</p>
  </motion.div>
);

const ProductGrid: React.FC<ProductGridProps> = ({ concept, products, layout, itemsPerPage = 9, isLoading = false }) => {
  const [filter, setFilter] = useState('all');
  const [sort, setSort] = useState('price-asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [gridContent, setGridContent] = useState<string>('');
  const gridRef = useRef<HTMLDivElement>(null);

  const getThemeClasses = (concept: Concept) => {
    switch (concept) {
        case 'classic':
            return 'bg-gray-100 text-gray-800';
        case 'modern':
            return 'bg-black text-white';
        case 'minimalist':
            return 'bg-white text-gray-900';
        default:
            return 'bg-white text-black';
    }
  };

  const themeClasses = getThemeClasses(concept);

  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    if (filter !== 'all') {
      result = result.filter(p => p.category === filter);
    }

    result.sort((a, b) => {
      switch (sort) {
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'name-asc':
          return a.name.localeCompare(b.name);
        case 'name-desc':
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });

    return result;
  }, [products, filter, sort]);

  const paginatedProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedProducts.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedProducts, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredAndSortedProducts.length / itemsPerPage);

  useEffect(() => {
    if (isLoading) {
      setGridContent('Loading products...');
    } else {
      setGridContent(`Showing ${paginatedProducts.length} of ${filteredAndSortedProducts.length} products`);
    }
  }, [isLoading, paginatedProducts.length, filteredAndSortedProducts.length]);

  const renderLayout = () => {
    if (isLoading) {
        return <div className="flex justify-center items-center h-64" role="status" aria-live="polite"><div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-gray-900"></div></div>;
    }
    if (paginatedProducts.length === 0) {
        return <div className="text-center py-16 font-light tracking-[0.15em] uppercase" role="alert">No products found.</div>
    }
    return (
        <AnimatePresence>
            {(() => {
                switch (layout) {
                    case '3-col':
                        return (
                        <div ref={gridRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16" aria-live="polite" aria-atomic="true">
                            {paginatedProducts.map(product => (
                            <ProductCard key={product.id} product={product} />
                            ))}
                        </div>
                        );
                    case 'masonry':
                        return (
                        <div ref={gridRef} className="columns-1 sm:columns-2 lg:columns-3 gap-8" aria-live="polite" aria-atomic="true">
                            {paginatedProducts.map(product => (
                            <div key={product.id} className="mb-8 break-inside-avoid">
                                <ProductCard product={product} />
                            </div>
                            ))}
                        </div>
                        );
                    case 'table':
                        return (
                        <table className="w-full text-left" aria-live="polite" aria-atomic="true">
                            <thead>
                            <tr>
                                <th scope="col" className="font-normal tracking-[0.15em] uppercase pb-4">Product</th>
                                <th scope="col" className="font-normal tracking-[0.15em] uppercase pb-4">Price</th>
                            </tr>
                            </thead>
                            <tbody>
                            {paginatedProducts.map(product => (
                                <tr key={product.id}>
                                <td className="py-4">
                                    <div className="flex items-center">
                                    <img src={product.imageUrl} alt={product.name} className="w-24 h-24 mr-8" />
                                    <h3 className="font-normal text-lg tracking-[0.15em] uppercase">{product.name}</h3>
                                    </div>
                                </td>
                                <td className="py-4 font-light text-base">${product.price.toFixed(2)}</td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                        );
                    case 'single':
                        return (
                        <div ref={gridRef} className="flex flex-col items-center" aria-live="polite" aria-atomic="true">
                            {paginatedProducts.map(product => (
                            <div key={product.id} className="w-full md:w-2/3 lg:w-1/2 mb-16">
                                <ProductCard product={product} />
                            </div>
                            ))}
                        </div>
                        );
                    default:
                        return null;
                }
            })()}
        </AnimatePresence>
    )
  };

  return (
    <section className={`py-[10vh] px-4 md:px-8 ${themeClasses}`}>
        <div className="container mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center mb-12" role="toolbar">
                <div className="flex items-center mb-4 md:mb-0">
                    <label htmlFor="filter" className="mr-4 font-normal tracking-[0.15em] uppercase">Filter:</label>
                    <select id="filter" value={filter} onChange={e => { setFilter(e.target.value); setCurrentPage(1); }} className="bg-transparent border-b border-current py-2 px-3 font-light">
                        <option value="all">All</option>
                        {[...new Set(products.map(p => p.category))].map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
                <div className="flex items-center">
                    <label htmlFor="sort" className="mr-4 font-normal tracking-[0.15em] uppercase">Sort:</label>
                    <select id="sort" value={sort} onChange={e => { setSort(e.target.value); setCurrentPage(1); }} className="bg-transparent border-b border-current py-2 px-3 font-light">
                        <option value="price-asc">Price: Low to High</option>
                        <option value="price-desc">Price: High to Low</option>
                        <option value="name-asc">Name: A-Z</option>
                        <option value="name-desc">Name: Z-A</option>
                    </select>
                </div>
            </div>
            <div aria-live="polite" className="sr-only">{gridContent}</div>
            {renderLayout()}
            {!isLoading && totalPages > 1 && (
                <nav className="flex justify-center items-center mt-16" aria-label="Pagination">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                        <button key={page} onClick={() => setCurrentPage(page)} className={`mx-2 px-4 py-2 rounded-full font-light tracking-[0.15em] uppercase transition-colors duration-300 ${currentPage === page ? 'bg-current text-white' : 'bg-transparent hover:bg-gray-200'}`} aria-current={currentPage === page ? 'page' : undefined}>{page}</button>
                    ))}
                </nav>
            )}
        </div>
    </section>
  );
};

export default ProductGrid;
