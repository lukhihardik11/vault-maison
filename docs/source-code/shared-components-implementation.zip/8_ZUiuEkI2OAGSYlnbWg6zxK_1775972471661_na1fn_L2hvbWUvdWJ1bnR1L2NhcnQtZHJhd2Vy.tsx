
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Minus } from "lucide-react";
import React, { useEffect } from "react";
import FocusTrap from "focus-trap-react";

// --- TYPES AND INTERFACES ---
type Concept = `concept${1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10}`;

interface CartItem {
  id: string | number;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  concept: Concept;
}

// --- THEMING ---
const themes: Record<Concept, Record<string, string>> = {
  concept1: {
    bg: "bg-gray-900",
    text: "text-white",
    heading: "text-white",
    subtleText: "text-gray-400",
    buttonBg: "bg-white",
    buttonText: "text-gray-900",
    borderColor: "border-gray-700",
  },
  concept2: { bg: "bg-blue-900", text: "text-white", heading: "text-white", subtleText: "text-blue-300", buttonBg: "bg-white", buttonText: "text-blue-900", borderColor: "border-blue-700" },
  concept3: { bg: "bg-green-900", text: "text-white", heading: "text-white", subtleText: "text-green-300", buttonBg: "bg-white", buttonText: "text-green-900", borderColor: "border-green-700" },
  concept4: { bg: "bg-purple-900", text: "text-white", heading: "text-white", subtleText: "text-purple-300", buttonBg: "bg-white", buttonText: "text-purple-900", borderColor: "border-purple-700" },
  concept5: { bg: "bg-pink-900", text: "text-white", heading: "text-white", subtleText: "text-pink-300", buttonBg: "bg-white", buttonText: "text-pink-900", borderColor: "border-pink-700" },
  concept6: { bg: "bg-yellow-900", text: "text-white", heading: "text-white", subtleText: "text-yellow-300", buttonBg: "bg-white", buttonText: "text-yellow-900", borderColor: "border-yellow-700" },
  concept7: { bg: "bg-indigo-900", text: "text-white", heading: "text-white", subtleText: "text-indigo-300", buttonBg: "bg-white", buttonText: "text-indigo-900", borderColor: "border-indigo-700" },
  concept8: { bg: "bg-red-900", text: "text-white", heading: "text-white", subtleText: "text-red-300", buttonBg: "bg-white", buttonText: "text-red-900", borderColor: "border-red-700" },
  concept9: { bg: "bg-teal-900", text: "text-white", heading: "text-white", subtleText: "text-teal-300", buttonBg: "bg-white", buttonText: "text-teal-900", borderColor: "border-teal-700" },
  concept10: { bg: "bg-gray-100", text: "text-gray-800", heading: "text-black", subtleText: "text-gray-500", buttonBg: "bg-black", buttonText: "text-white", borderColor: "border-gray-300" },
};

// --- SUB-COMPONENTS ---
const CartItemComponent: React.FC<{ item: CartItem; theme: Record<string, string> }> = ({ item, theme }) => (
  <div className={`flex items-center py-6 border-b ${theme.borderColor}`}>
    <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md" />
    <div className="ml-4 flex-1">
      <h3 className={`font-light tracking-[0.15em] uppercase ${theme.heading}`}>{item.name}</h3>
      <p className={`text-sm ${theme.subtleText}`}>${item.price.toFixed(2)}</p>
      <div className="flex items-center mt-2">
        <button aria-label={`Decrease quantity of ${item.name}`} className={`p-1 rounded-full ${theme.buttonBg}`}><Minus size={16} className={theme.buttonText} /></button>
        <span className={`mx-4 font-light ${theme.text}`}>{item.quantity}</span>
        <button aria-label={`Increase quantity of ${item.name}`} className={`p-1 rounded-full ${theme.buttonBg}`}><Plus size={16} className={theme.buttonText} /></button>
      </div>
    </div>
    <button aria-label={`Remove ${item.name} from cart`} className={`ml-4 ${theme.subtleText}`}><X size={20} /></button>
  </div>
);

// --- MAIN COMPONENT ---
const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, items, concept }) => {
  const theme = themes[concept];
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener("keydown", handleKeyDown);
    } else {
      document.removeEventListener("keydown", handleKeyDown);
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);


  return (
    <AnimatePresence>
      {isOpen && (
        <FocusTrap focusTrapOptions={{ initialFocus: false }}>
          <div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6 }}
              className="fixed inset-0 bg-black z-40"
              onClick={onClose}
              aria-hidden="true"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
              className={`fixed top-0 right-0 w-full max-w-md h-full ${theme.bg} ${theme.text} shadow-2xl z-50 flex flex-col font-light`}
              role="dialog"
              aria-modal="true"
              aria-labelledby="cart-drawer-heading"
            >
              <header className={`flex items-center justify-between p-6 border-b ${theme.borderColor}`}>
                <h2 id="cart-drawer-heading" className="text-xl font-normal tracking-[0.15em] uppercase">Your Cart</h2>
                <button onClick={onClose} className={theme.text} aria-label="Close cart"><X size={24} /></button>
              </header>

              <main className="flex-1 overflow-y-auto px-6 py-[10vh]">
                {items.length > 0 ? (
                  items.map(item => <CartItemComponent key={item.id} item={item} theme={theme} />)
                ) : (
                  <div className="text-center py-20">
                    <p className={theme.subtleText}>Your cart is empty.</p>
                  </div>
                )}
              </main>

              <footer className={`p-6 border-t ${theme.borderColor}`}>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-lg font-normal tracking-[0.15em] uppercase">Subtotal</span>
                  <span className="text-lg font-normal" aria-live="polite">${subtotal.toFixed(2)}</span>
                </div>
                <button className={`w-full py-4 ${theme.buttonBg} ${theme.buttonText} font-normal tracking-[0.15em] uppercase transition-colors duration-300 hover:opacity-90`}>
                  Proceed to Checkout
                </button>
              </footer>
            </motion.div>
          </div>
        </FocusTrap>
      )}
    </AnimatePresence>
  );
};

export default CartDrawer;
