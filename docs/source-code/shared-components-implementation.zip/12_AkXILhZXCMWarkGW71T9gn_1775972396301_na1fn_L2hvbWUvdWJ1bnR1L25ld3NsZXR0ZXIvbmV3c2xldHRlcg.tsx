import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Define the concept themes
const themes = {
  'concept1': {
    bgColor: 'bg-white',
    textColor: 'text-black',
    buttonColor: 'bg-black',
    buttonTextColor: 'text-white',
    inputBorderColor: 'border-gray-300',
    inputFocusRingColor: 'focus:ring-black',
  },
  'concept2': {
    bgColor: 'bg-black',
    textColor: 'text-white',
    buttonColor: 'bg-white',
    buttonTextColor: 'text-black',
    inputBorderColor: 'border-gray-700',
    inputFocusRingColor: 'focus:ring-white',
  },
  'concept3': {
    bgColor: 'bg-stone-100',
    textColor: 'text-stone-800',
    buttonColor: 'bg-stone-800',
    buttonTextColor: 'text-white',
    inputBorderColor: 'border-stone-300',
    inputFocusRingColor: 'focus:ring-stone-800',
  },
  'concept4': {
    bgColor: 'bg-neutral-900',
    textColor: 'text-neutral-100',
    buttonColor: 'bg-neutral-100',
    buttonTextColor: 'text-neutral-900',
    inputBorderColor: 'border-neutral-700',
    inputFocusRingColor: 'focus:ring-neutral-100',
  },
  'concept5': {
    bgColor: 'bg-amber-50',
    textColor: 'text-amber-900',
    buttonColor: 'bg-amber-900',
    buttonTextColor: 'text-amber-50',
    inputBorderColor: 'border-amber-300',
    inputFocusRingColor: 'focus:ring-amber-900',
  },
  'concept6': {
    bgColor: 'bg-slate-900',
    textColor: 'text-slate-100',
    buttonColor: 'bg-slate-100',
    buttonTextColor: 'text-slate-900',
    inputBorderColor: 'border-slate-700',
    inputFocusRingColor: 'focus:ring-slate-100',
  },
  'concept7': {
    bgColor: 'bg-zinc-100',
    textColor: 'text-zinc-800',
    buttonColor: 'bg-zinc-800',
    buttonTextColor: 'text-white',
    inputBorderColor: 'border-zinc-300',
    inputFocusRingColor: 'focus:ring-zinc-800',
  },
  'concept8': {
    bgColor: 'bg-indigo-950',
    textColor: 'text-indigo-100',
    buttonColor: 'bg-indigo-100',
    buttonTextColor: 'text-indigo-950',
    inputBorderColor: 'border-indigo-800',
    inputFocusRingColor: 'focus:ring-indigo-100',
  },
  'concept9': {
    bgColor: 'bg-rose-50',
    textColor: 'text-rose-900',
    buttonColor: 'bg-rose-900',
    buttonTextColor: 'text-rose-50',
    inputBorderColor: 'border-rose-300',
    inputFocusRingColor: 'focus:ring-rose-900',
  },
  'concept10': {
    bgColor: 'bg-teal-950',
    textColor: 'text-teal-100',
    buttonColor: 'bg-teal-100',
    buttonTextColor: 'text-teal-950',
    inputBorderColor: 'border-teal-800',
    inputFocusRingColor: 'focus:ring-teal-100',
  },
};

// Define the props interface
interface NewsletterProps {
  concept: keyof typeof themes;
}

const Newsletter: React.FC<NewsletterProps> = ({ concept }) => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const theme = themes[concept];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError(null);
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1200));

    setIsLoading(false);
    setIsSubmitted(true);
  };

  return (
    <div className={`py-[10vh] ${theme.bgColor} ${theme.textColor}`}>
      <div className="container mx-auto px-4">
        <AnimatePresence mode="wait">
          {isSubmitted ? (
            <motion.div
              key="success"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
              className="text-center"
            >
              <h2 className="text-2xl font-light tracking-[0.15em] uppercase">Thank You</h2>
              <p className="font-light mt-2">You have successfully subscribed to our newsletter.</p>
            </motion.div>
          ) : (
            <motion.div
              key="form"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
            >
              <h2 className="text-4xl font-normal tracking-[0.15em] uppercase text-center mb-4">Join The List</h2>
              <p className="text-center font-light mb-8 max-w-2xl mx-auto">Be the first to know about new collections, special events, and what’s inspiring the world of Vault-Maison.</p>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row justify-center items-center gap-4 max-w-lg mx-auto">
                <div className="relative w-full">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email address"
                    className={`w-full px-4 py-3 font-light bg-transparent border ${theme.inputBorderColor} ${theme.inputFocusRingColor} focus:outline-none focus:ring-1 transition-colors duration-300`}
                    aria-label="Email address"
                    aria-invalid={!!error}
                    aria-describedby={error ? "email-error" : undefined}
                    disabled={isLoading}
                  />
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  type="submit"
                  className={`px-8 py-3 font-normal tracking-[0.15em] uppercase ${theme.buttonColor} ${theme.buttonTextColor} whitespace-nowrap`}
                  disabled={isLoading}
                >
                  {isLoading ? 'Subscribing...' : 'Subscribe'}
                </motion.button>
              </form>
              {error && <p id="email-error" className="text-red-500 text-center mt-4 font-light">{error}</p>}
              <p className="text-xs text-center mt-4 font-light">We respect your privacy. Unsubscribe at any time. <a href="/privacy-policy" className="underline">Privacy Policy</a>.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Newsletter;
