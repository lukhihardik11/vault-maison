import React from 'react';
import { motion, MotionProps } from 'framer-motion';
import { Heart, Eye } from 'lucide-react'; // Example icons

export type JewelryConcept = 
  | 'ethereal-garden'
  | 'midnight-bloom'
  | 'celestial-dream'
  | 'regal-romance'
  | 'avant-garde'
  | 'sacred-geometry'
  | 'opulent-oasis'
  | 'art-deco-revival'
  | 'celestial-symphony'
  | 'mythical-creatures';

export interface Product {
  id: string;
  name: string;
  price: number;
  currency: string;
  images: {
    default: string;
    hover: string;
  };
  quickViewVideo?: string;
}

export interface ProductCardProps extends MotionProps {
  product: Product;
  concept: JewelryConcept;
  className?: string;
}

const themes = {
  'ethereal-garden': {
    '--background': '#f0f4f0',
    '--foreground': '#333',
    '--accent': '#8da88d',
    '--card-background': '#ffffff',
    '--card-foreground': '#000000',
  },
  'midnight-bloom': {
    '--background': '#1a1a1a',
    '--foreground': '#ffffff',
    '--accent': '#a4a4a4',
    '--card-background': '#2a2a2a',
    '--card-foreground': '#ffffff',
  },
    'celestial-dream': {
    '--background': '#0f1a2e',
    '--foreground': '#e0e5f0',
    '--accent': '#a0b0d0',
    '--card-background': '#182848',
    '--card-foreground': '#ffffff',
  },
  'regal-romance': {
    '--background': '#f4e9ef',
    '--foreground': '#4b2e39',
    '--accent': '#c48daA',
    '--card-background': '#ffffff',
    '--card-foreground': '#000000',
  },
  'avant-garde': {
    '--background': '#e0e0e0',
    '--foreground': '#1a1a1a',
    '--accent': '#ff4500',
    '--card-background': '#000000',
    '--card-foreground': '#ffffff',
  },
  'sacred-geometry': {
    '--background': '#f5f5f5',
    '--foreground': '#333333',
    '--accent': '#b8860b',
    '--card-background': '#ffffff',
    '--card-foreground': '#000000',
  },
  'opulent-oasis': {
    '--background': '#fdf6e3',
    '--foreground': '#654321',
    '--accent': '#008080',
    '--card-background': '#ffffff',
    '--card-foreground': '#000000',
  },
  'art-deco-revival': {
    '--background': '#2c2c2c',
    '--foreground': '#f0e6d2',
    '--accent': '#d4af37',
    '--card-background': '#1a1a1a',
    '--card-foreground': '#ffffff',
  },
  'celestial-symphony': {
    '--background': '#000020',
    '--foreground': '#e6e6fa',
    '--accent': '#ffc0cb',
    '--card-background': '#191970',
    '--card-foreground': '#ffffff',
  },
  'mythical-creatures': {
    '--background': '#f0e8d8',
    '--foreground': '#4b382a',
    '--accent': '#8b0000',
    '--card-background': '#ffffff',
    '--card-foreground': '#000000',
  },
};

export const ProductCard: React.FC<ProductCardProps> = ({ product, concept, className, ...props }) => {
  const [isHovered, setIsHovered] = React.useState(false);
  const [isWishlisted, setIsWishlisted] = React.useState(false);
  const theme = themes[concept] || themes['ethereal-garden'];

  const handleWishlistToggle = () => {
    setIsWishlisted(!isWishlisted);
  };

  return (
    <motion.div
      className={`relative overflow-hidden rounded-lg shadow-lg w-full max-w-sm mx-auto ${className}`}
      style={theme as React.CSSProperties}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      aria-label={product.name}
      role="group"
      {...props}
    >
      <div className="relative w-full aspect-square">
        <motion.img
          src={product.images.default}
          alt={product.name}
          className="absolute top-0 left-0 w-full h-full object-cover"
          animate={{ opacity: isHovered ? 0 : 1 }}
          transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
        />
        <motion.img
          src={product.images.hover}
          alt={`${product.name} hover view`}
          className="absolute top-0 left-0 w-full h-full object-cover"
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
        />
        <motion.div 
          className="absolute top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-40"
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 1, ease: [0.43, 0.13, 0.23, 0.96] }}
        >
            <button className="text-white mx-2 flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full hover:bg-white/20 transition-colors duration-300" aria-label="Quick view">
                <Eye size={20} />
                <span>Quick View</span>
            </button>
        </motion.div>
        <button 
            onClick={handleWishlistToggle} 
            className="absolute top-4 right-4 text-white bg-black/30 p-2 rounded-full hover:bg-black/50 transition-colors duration-300" 
            aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
            aria-pressed={isWishlisted}
        >
            <Heart size={24} fill={isWishlisted ? 'currentColor' : 'none'} />
        </button>
      </div>

      <div className="p-6 text-center">
        <h3 className="text-xl font-normal tracking-[0.15em] uppercase text-[var(--card-foreground)]">{product.name}</h3>
        <p className="text-lg font-light text-[var(--card-foreground)] mt-2">{`${product.currency}${product.price}`}</p>
      </div>
    </motion.div>
  );
};
