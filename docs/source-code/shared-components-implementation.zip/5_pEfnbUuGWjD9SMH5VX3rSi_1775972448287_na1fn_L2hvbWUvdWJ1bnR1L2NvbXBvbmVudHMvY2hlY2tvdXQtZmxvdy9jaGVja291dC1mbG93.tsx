'''
import React, { useState, createContext, useContext } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckoutFlowProps, CheckoutStep, Concept } from './types';

interface CheckoutContextType {
  nextStep: () => void;
  prevStep: () => void;
  step: number;
  steps: CheckoutStep[];
  concept: Concept;
}

const CheckoutContext = createContext<CheckoutContextType | undefined>(undefined);

export const useCheckout = () => {
  const context = useContext(CheckoutContext);
  if (!context) {
    throw new Error('useCheckout must be used within a CheckoutProvider');
  }
  return context;
};

const CheckoutFlow: React.FC<CheckoutFlowProps> = ({ concept, steps, onSubmit }) => {
  const [step, setStep] = useState(0);
  const currentStep = steps[step];
  const methods = useForm({
    resolver: zodResolver(currentStep.validationSchema),
    defaultValues: {},
  });

  const nextStep = async () => {
    const isValid = await methods.trigger(currentStep.fields);
    if (isValid) {
      if (step < steps.length - 1) {
        setStep(step + 1);
      } else {
        onSubmit(methods.getValues());
      }
    }
  };

  const prevStep = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  const getTheme = (concept: Concept) => {
    // In a real application, this would be more sophisticated
    const themes: Record<Concept, { bg: string; text: string; accent: string }> = {
      concept1: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept2: { bg: 'bg-blue-100', text: 'text-blue-800', accent: 'text-green-500' },
      // ... other concepts
      concept3: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept4: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept5: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept6: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept7: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept8: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept9: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
      concept10: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-blue-500' },
    };
    return themes[concept];
  };

  const theme = getTheme(concept);

  return (
    <CheckoutContext.Provider value={{ nextStep, prevStep, step, steps, concept }}>
      <FormProvider {...methods}>
        <div className={`font-light tracking-[0.15em] ${theme.bg} ${theme.text} min-h-screen flex flex-col items-center justify-center py-[10vh]`}>
          <div className="w-full max-w-4xl mx-auto">
            {/* Progress Indicator */}
            <div className="flex justify-between items-center mb-8">
              {steps.map((s, i) => (
                <React.Fragment key={i}>
                  <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= i ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'}`}>
                      <s.icon className="w-5 h-5" />
                    </div>
                    <div className={`ml-4 font-medium uppercase ${step >= i ? theme.accent : 'text-gray-500'}`}>{s.title}</div>
                  </div>
                  {i < steps.length - 1 && <div className="flex-1 h-px bg-gray-300 mx-4"></div>}
                </React.Fragment>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
              >
                {React.cloneElement(currentStep.component, { concept })}
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex justify-between mt-8">
              {step > 0 && (
                <button onClick={prevStep} className="px-6 py-2 border border-gray-400 rounded-md uppercase font-semibold hover:bg-gray-200 transition-colors duration-300">
                  Previous
                </button>
              )}
              <button onClick={nextStep} className="px-6 py-2 bg-blue-500 text-white rounded-md uppercase font-semibold hover:bg-blue-600 transition-colors duration-300">
                {step === steps.length - 1 ? 'Place Order' : 'Next'}
              </button>
            </div>
          </div>
        </div>
      </FormProvider>
    </CheckoutContext.Provider>
  );
};

export default CheckoutFlow;
'''
