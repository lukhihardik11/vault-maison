import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// Define the concept names as a union type for type safety
type Concept = 'concept1' | 'concept2' | 'concept3' | 'concept4' | 'concept5' | 'concept6' | 'concept7' | 'concept8' | 'concept9' | 'concept10';

// Define the props interface for the ConceptSwitcher component
interface ConceptSwitcherProps {
  concept: Concept;
  setConcept: (concept: Concept) => void;
}

// Array of concept objects, each with a name and a preview image path
const concepts: { name: Concept; preview: string }[] = [
    { name: 'concept1', preview: '/previews/concept1.jpg' },
    { name: 'concept2', preview: '/previews/concept2.jpg' },
    { name: 'concept3', preview: '/previews/concept3.jpg' },
    { name: 'concept4', preview: '/previews/concept4.jpg' },
    { name: 'concept5', preview: '/previews/concept5.jpg' },
    { name: 'concept6', preview: '/previews/concept6.jpg' },
    { name: 'concept7', preview: '/previews/concept7.jpg' },
    { name: 'concept8', preview: '/previews/concept8.jpg' },
    { name: 'concept9', preview: '/previews/concept9.jpg' },
    { name: 'concept10', preview: '/previews/concept10.jpg' },
];

const ConceptSwitcher: React.FC<ConceptSwitcherProps> = ({ concept, setConcept }) => {
  const [hoveredConcept, setHoveredConcept] = useState<Concept | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate a loading state for the component
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-16 h-16 border-t-2 border-b-2 border-gray-900 rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-gray-100 font-light tracking-[0.15em] py-[10vh]">
      <AnimatePresence>
        {hoveredConcept && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.6, ease: [0.43, 0.13, 0.23, 0.96] }}
            className="absolute inset-0 w-full h-full z-0"
          >
            <img
              src={concepts.find(c => c.name === hoveredConcept)?.preview}
              alt={`${hoveredConcept} preview`}
              className="object-cover w-full h-full"
            />
            <div className="absolute inset-0 bg-black bg-opacity-50" />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="relative z-10 flex items-center justify-center space-x-2 md:space-x-4 p-4">
        {concepts.map(({ name }) => (
          <motion.button
            key={name}
            onMouseEnter={() => setHoveredConcept(name)}
            onMouseLeave={() => setHoveredConcept(null)}
            onClick={() => setConcept(name)}
            className={`relative px-3 py-2 md:px-4 md:py-2 text-sm md:text-base uppercase transition-colors duration-300`}
            aria-label={`Switch to ${name}`}
            aria-current={concept === name ? 'page' : undefined}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className={`${concept === name ? 'text-white' : 'text-gray-400'} hover:text-white`}>
              {name.replace('concept', 'C')}
            </span>
            {concept === name && (
              <motion.div
                layoutId="activeConceptIndicator"
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-white"
                initial={false}
                transition={{ duration: 0.6, ease: [0.43, 0.13, 0.23, 0.96] }}
              />
            )}
          </motion.button>
        ))}
      </div>

      <div className="mt-8 text-center">
        <h1 className="text-2xl md:text-4xl font-normal text-white uppercase tracking-[0.15em]">Concept {concept.replace('concept', '')}</h1>
      </div>
    </div>
  );
};

export default ConceptSwitcher;
