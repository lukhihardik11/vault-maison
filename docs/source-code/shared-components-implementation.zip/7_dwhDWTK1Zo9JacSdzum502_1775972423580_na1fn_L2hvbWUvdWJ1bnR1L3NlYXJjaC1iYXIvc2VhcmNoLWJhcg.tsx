
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X } from 'lucide-react';
import { Concept, Product, SearchBarProps } from './types';

// --- Mock API --- //
const mockProducts: Product[] = [
  { id: '1', name: 'Diamond Solitaire Ring', imageUrl: '/placeholder.svg', price: 2500 },
  { id: '2', name: 'Sapphire Tennis Bracelet', imageUrl: '/placeholder.svg', price: 7800 },
  { id: '3', name: 'Emerald Cut Necklace', imageUrl: '/placeholder.svg', price: 12000 },
  { id: '4', name: 'Pearl Drop Earrings', imageUrl: '/placeholder.svg', price: 1200 },
  { id: '5', name: 'Ruby Eternity Band', imageUrl: '/placeholder.svg', price: 4500 },
  { id: '6', name: 'Gold Bangle', imageUrl: '/placeholder.svg', price: 1800 },
];

const fetchSearchResults = async (query: string): Promise<Product[]> => {
  console.log(`Searching for: ${query}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      if (!query) {
        resolve([]);
        return;
      }
      const lowercasedQuery = query.toLowerCase();
      const results = mockProducts.filter((product) =>
        product.name.toLowerCase().includes(lowercasedQuery)
      );
      resolve(results);
    }, 500);
  });
};

// --- Hooks --- //
const useDebounce = (value: string, delay: number) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
};

// --- Theming --- //
const themes: Record<Concept, Record<string, string>> = {
  classic: {
    bg: 'bg-white',
    text: 'text-gray-800',
    border: 'border-gray-300',
    highlight: 'bg-gray-100',
    accent: 'text-gray-600',
  },
  modern: {
    bg: 'bg-black',
    text: 'text-white',
    border: 'border-gray-700',
    highlight: 'bg-gray-800',
    accent: 'text-gray-400',
  },
  // Add other 8 concepts here...
  minimalist: { bg: 'bg-gray-50', text: 'text-gray-900', border: 'border-gray-200', highlight: 'bg-gray-200', accent: 'text-gray-500' },
  vintage: { bg: '#fdf6e3', text: '#654321', border: 'border-[#d3c0a5]', highlight: 'bg-[#f4e9d8]', accent: 'text-[#8b4513]' },
  edgy: { bg: '#1a1a1a', text: '#e0e0e0', border: 'border-red-500', highlight: 'bg-gray-700', accent: 'text-red-500' },
  bohemian: { bg: '#f5f5dc', text: '#8b5a2b', border: 'border-green-700', highlight: 'bg-[#e9e4d4]', accent: 'text-green-800' },
  'art-deco': { bg: '#000000', text: '#ffd700', border: 'border-gold-500', highlight: 'bg-gray-800', accent: 'text-gold-300' },
  industrial: { bg: '#333333', text: '#cccccc', border: 'border-gray-500', highlight: 'bg-gray-600', accent: 'text-gray-400' },
  scandinavian: { bg: '#f9f9f9', text: '#333333', border: 'border-gray-200', highlight: 'bg-blue-100', accent: 'text-blue-500' },
  coastal: { bg: '#e0f7fa', text: '#006064', border: 'border-cyan-300', highlight: 'bg-cyan-100', accent: 'text-cyan-800' },
};

// --- Component --- //
const SearchBar: React.FC<SearchBarProps> = ({ concept }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const debouncedQuery = useDebounce(query, 300);
  const searchRef = useRef<HTMLDivElement>(null);

  const theme = themes[concept] || themes.classic;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    if (debouncedQuery) {
      setIsLoading(true);
      fetchSearchResults(debouncedQuery).then((res) => {
        setResults(res);
        setIsLoading(false);
        setIsOpen(true);
        setActiveIndex(-1);
      });
    } else {
      setResults([]);
      setIsOpen(false);
    }
  }, [debouncedQuery]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter' && activeIndex > -1) {
      e.preventDefault();
      window.location.href = `/products/${results[activeIndex].id}`;
    }
  };

  return (
    <div ref={searchRef} className={`relative w-full max-w-md mx-auto font-light tracking-[0.15em] ${theme.text}`}>
      <div className={`relative flex items-center ${theme.bg} border ${theme.border} rounded-full transition-all duration-600`}>
        <span className="pl-4 pr-2">
          <Search size={20} className={theme.accent} />
        </span>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder="Search for treasures..."
          className={`w-full py-3 bg-transparent outline-none placeholder-${theme.accent}`}
          aria-label="Search"
          aria-autocomplete="list"
          aria-expanded={isOpen}
          aria-controls="search-results"
        />
        {query && (
          <button onClick={() => setQuery('')} className="pr-4 pl-2">
            <X size={20} className={theme.accent} />
          </button>
        )}
      </div>

      <AnimatePresence>
        {isOpen && (query || isLoading) && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.6, ease: [0.43, 0.13, 0.23, 0.96] }}
            className={`absolute w-full mt-2 ${theme.bg} border ${theme.border} rounded-lg shadow-lg overflow-hidden z-10`}
            id="search-results"
            role="listbox"
          >
            {isLoading ? (
              <div className="p-4 text-center">Loading...</div>
            ) : results.length > 0 ? (
              <ul>
                {results.map((product, index) => (
                  <li
                    key={product.id}
                    role="option"
                    aria-selected={index === activeIndex}
                    className={`${index === activeIndex ? theme.highlight : ''} transition-colors duration-300`}
                    onMouseMove={() => setActiveIndex(index)}
                  >
                    <a href={`/products/${product.id}`} className="flex items-center p-4">
                      <img src={product.imageUrl} alt={product.name} className="w-16 h-16 object-cover mr-4 rounded" />
                      <div>
                        <h3 className="font-normal text-base tracking-normal">{product.name}</h3>
                        <p className={`${theme.accent}`}>${product.price.toLocaleString()}</p>
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-4 text-center">No results found.</div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchBar;
