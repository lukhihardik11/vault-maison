import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, X } from 'lucide-react';
import { Concept, FilterSidebarProps, Filter, FilterOption } from './filter-sidebar.types';

const conceptThemes: Record<Concept, any> = {
    concept1: { bg: 'bg-gray-100', text: 'text-gray-800', accent: 'text-black' },
    concept2: { bg: 'bg-blue-100', text: 'text-blue-800', accent: 'text-blue-900' },
    concept3: { bg: 'bg-green-100', text: 'text-green-800', accent: 'text-green-900' },
    concept4: { bg: 'bg-purple-100', text: 'text-purple-800', accent: 'text-purple-900' },
    concept5: { bg: 'bg-pink-100', text: 'text-pink-800', accent: 'text-pink-900' },
    concept6: { bg: 'bg-yellow-100', text: 'text-yellow-800', accent: 'text-yellow-900' },
    concept7: { bg: 'bg-indigo-100', text: 'text-indigo-800', accent: 'text-indigo-900' },
    concept8: { bg: 'bg-red-100', text: 'text-red-800', accent: 'text-red-900' },
    concept9: { bg: 'bg-teal-100', text: 'text-teal-800', accent: 'text-teal-900' },
    concept10: { bg: 'bg-gray-900', text: 'text-white', accent: 'text-gray-400' },
};

const FilterSidebar: React.FC<FilterSidebarProps> = ({ concept, filters, onFilterChange, loading }) => {
    const [openSections, setOpenSections] = useState<Record<string, boolean>>({});
    const [filterValues, setFilterValues] = useState<Record<string, any>>({});

    const handleCheckboxChange = (filterId: string, value: string, checked: boolean) => {
        const newValues = { ...filterValues };
        if (checked) {
            newValues[filterId] = [...(newValues[filterId] || []), value];
        } else {
            newValues[filterId] = (newValues[filterId] || []).filter((v: string) => v !== value);
        }
        setFilterValues(newValues);
        onFilterChange(newValues);
    };

    const handleRangeChange = (filterId: string, value: string) => {
        const newValues = { ...filterValues, [filterId]: value };
        setFilterValues(newValues);
        onFilterChange(newValues);
    };

    const handleColorChange = (filterId: string, value: string) => {
        const newValues = { ...filterValues, [filterId]: value };
        setFilterValues(newValues);
        onFilterChange(newValues);
    };
    const [isMobileDrawerOpen, setMobileDrawerOpen] = useState(false);

    const theme = useMemo(() => conceptThemes[concept], [concept]);

    const toggleSection = (id: string) => {
        setOpenSections(prev => ({ ...prev, [id]: !prev[id] }));
    };

    return (
        <>
            {/* Mobile filter button */}
            <div className="lg:hidden">
                <button onClick={() => setMobileDrawerOpen(true)} className={`fixed bottom-4 right-4 z-50 p-4 rounded-full shadow-lg ${theme.bg} ${theme.accent}`}>Filters</button>
            </div>

            {/* Sidebar */}
            <aside className={`hidden lg:block w-80 p-6 ${theme.bg} ${theme.text}`}>
                <fieldset disabled={loading}>
                {filters.map(filter => (
                    <div key={filter.id} className="py-[10vh]" role="region" aria-labelledby={`filter-heading-${filter.id}`}>
                        <h3 id={`filter-heading-${filter.id}`} onClick={() => toggleSection(filter.id)} className="flex items-center justify-between cursor-pointer font-normal text-lg tracking-[0.15em] uppercase" aria-controls={`filter-section-${filter.id}`} aria-expanded={openSections[filter.id]}>
                            {filter.name}
                            <motion.div animate={{ rotate: openSections[filter.id] ? 180 : 0 }} transition={{ duration: 0.6 }}>
                                <ChevronDown size={20} />
                            </motion.div>
                        </h3>
                        <AnimatePresence>
                            {openSections[filter.id] && (
                                <motion.div
                                    id={`filter-section-${filter.id}`}
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ duration: 0.6, ease: [0.87, 0, 0.13, 1] }}
                                    className="overflow-hidden"
                                >
                                    {
                                        filter.type === 'checkbox' && filter.options && (
                                            <div className="pt-4 space-y-2">
                                                {filter.options.map(option => (
                                                    <div key={option.value} className="flex items-center">
                                                        <input
                                                            type="checkbox"
                                                            id={`${filter.id}-${option.value}`}
                                                            value={option.value}
                                                            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                                        onChange={(e) => handleCheckboxChange(filter.id, option.value, e.target.checked)}
                                                        />
                                                        <label htmlFor={`${filter.id}-${option.value}`} className="ml-3 text-sm font-light tracking-[0.15em]">
                                                            {option.label}
                                                        </label>
                                                    </div>
                                                ))}
                                            </div>
                                        )
                                    }
                                    {
                                        filter.type === 'range' && (
                                            <div className="pt-4">
                                                <input
                                                    type="range"
                                                    min={0}
                                                    max={10000}
                                                    onChange={(e) => handleRangeChange(filter.id, e.target.value)}
                                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                                    aria-label={filter.name}
                                                />
                                            </div>
                                        )
                                    }
                                    {
                                        filter.type === 'color' && filter.options && (
                                            <div className="pt-4 flex flex-wrap gap-2">
                                                {filter.options.map(option => (
                                                    <button
                                                        key={option.value}
                                                        onClick={() => handleColorChange(filter.id, option.value)}
                                                        className={`w-8 h-8 rounded-full border-2 ${filterValues[filter.id] === option.value ? 'border-black' : 'border-transparent'}`}
                                                        style={{ backgroundColor: option.value }}
                                                        aria-label={option.label}
                                                    />
                                                ))}
                                            </div>
                                        )
                                    }
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                ))}
                </fieldset>
            </aside>

            {/* Mobile Drawer */}
            <AnimatePresence>
                {isMobileDrawerOpen && (
                    <motion.div
                        initial={{ x: '-100%' }}
                        animate={{ x: 0 }}
                        exit={{ x: '-100%' }}
                        transition={{ duration: 0.6, ease: [0.87, 0, 0.13, 1] }}
                        className={`fixed top-0 left-0 z-50 w-full h-full lg:hidden ${theme.bg} ${theme.text} p-6`}
                    >
                        <div className="flex items-center justify-between mb-6">
                            <h2 className="font-normal text-xl tracking-[0.15em] uppercase">Filters</h2>
                            <button onClick={() => setMobileDrawerOpen(false)}>
                                <X size={24} />
                            </button>
                        </div>
                        {filters.map(filter => (
                            <div key={filter.id} className="py-4">
                                <h3 onClick={() => toggleSection(filter.id)} className="flex items-center justify-between cursor-pointer font-normal text-lg tracking-[0.15em] uppercase">
                                    {filter.name}
                                    <motion.div animate={{ rotate: openSections[filter.id] ? 180 : 0 }} transition={{ duration: 0.6 }}>
                                        <ChevronDown size={20} />
                                    </motion.div>
                                </h3>
                                <AnimatePresence>
                                    {openSections[filter.id] && (
                                        <motion.div
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            transition={{ duration: 0.6, ease: [0.87, 0, 0.13, 1] }}
                                            className="overflow-hidden"
                                        >
                                            {
                                        filter.type === 'checkbox' && filter.options && (
                                            <div className="pt-4 space-y-2">
                                                {filter.options.map(option => (
                                                    <div key={option.value} className="flex items-center">
                                                        <input
                                                            type="checkbox"
                                                            id={`${filter.id}-${option.value}`}
                                                            value={option.value}
                                                            className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                                        onChange={(e) => handleCheckboxChange(filter.id, option.value, e.target.checked)}
                                                        />
                                                        <label htmlFor={`${filter.id}-${option.value}`} className="ml-3 text-sm font-light tracking-[0.15em]">
                                                            {option.label}
                                                        </label>
                                                    </div>
                                                ))}
                                            </div>
                                        )
                                    }
                                    {
                                        filter.type === 'range' && (
                                            <div className="pt-4">
                                                <input
                                                    type="range"
                                                    min={0}
                                                    max={10000}
                                                    onChange={(e) => handleRangeChange(filter.id, e.target.value)}
                                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                                    aria-label={filter.name}
                                                />
                                            </div>
                                        )
                                    }
                                    {
                                        filter.type === 'color' && filter.options && (
                                            <div className="pt-4 flex flex-wrap gap-2">
                                                {filter.options.map(option => (
                                                    <button
                                                        key={option.value}
                                                        onClick={() => handleColorChange(filter.id, option.value)}
                                                        className={`w-8 h-8 rounded-full border-2 ${filterValues[filter.id] === option.value ? 'border-black' : 'border-transparent'}`}
                                                        style={{ backgroundColor: option.value }}
                                                    />
                                                ))}
                                            </div>
                                        )
                                    }
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        ))}
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default FilterSidebar;
