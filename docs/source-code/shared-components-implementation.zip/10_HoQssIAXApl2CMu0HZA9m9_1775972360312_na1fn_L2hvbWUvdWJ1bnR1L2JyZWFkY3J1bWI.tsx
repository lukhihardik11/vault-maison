
import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';

// Define the concept themes
const themes = {
  'concept-1': {
    textColor: 'text-gray-800',
    separatorColor: 'text-gray-400',
    hoverTextColor: 'text-black',
  },
  'concept-2': {
    textColor: 'text-red-800',
    separatorColor: 'text-red-400',
    hoverTextColor: 'text-red-900',
  },
  // Add other 8 concepts here
};

// Define the props interface
interface BreadcrumbProps {
  concept: keyof typeof themes;
}

const Breadcrumb: React.FC<BreadcrumbProps> = ({ concept }) => {
  const pathname = usePathname();
  const pathSegments = pathname.split('/').filter((segment) => segment);

  const theme = themes[concept];

  return (
    <nav aria-label="Breadcrumb" className="py-[10vh]">
      <ol className="flex items-center space-x-2 tracking-[0.15em] uppercase">
        <li>
          <Link href="/">
            <a className={`${theme.textColor} ${theme.hoverTextColor} font-light`}>Home</a>
          </Link>
        </li>
        {pathSegments.map((segment, index) => {
          const href = `/${pathSegments.slice(0, index + 1).join('/')}`;
          const isLast = index === pathSegments.length - 1;

          return (
            <React.Fragment key={href}>
              <li className={`${theme.separatorColor} font-light`}>/</li>
              <li>
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 + index * 0.2, ease: [0.6, 0.01, -0.05, 0.95] }}
                >
                  <Link href={href}>
                    <a
                      className={`${isLast ? 'font-normal' : 'font-light'} ${theme.textColor} ${theme.hoverTextColor}`}
                      aria-current={isLast ? 'page' : undefined}
                    >
                      {segment.replace(/-/g, ' ')}
                    </a>
                  </Link>
                </motion.div>
              </li>
            </React.Fragment>
          );
        })}
      </ol>
    </nav>
  );
};

export default Breadcrumb;
