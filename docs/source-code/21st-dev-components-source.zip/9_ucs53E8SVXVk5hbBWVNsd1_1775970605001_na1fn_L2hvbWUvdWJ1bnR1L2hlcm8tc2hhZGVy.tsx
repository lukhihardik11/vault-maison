/*
 {"$schema":"https://ui.shadcn.com/schema/registry-item.json","name":"hero-shader","type":"registry:component","title":"Hero Shader","description":"A hero-shader component.","dependencies":["@paper-design/shaders-react"],"registryDependencies":[],"files":[{"path":"src/components/ui/hero-shader.tsx","content":"\"use client\"\n\nimport type React from \"react\"\n\nimport { useEffect, useRef, useState } from \"react\"\nimport { MeshGradient } from \"@paper-design/shaders-react\"\n\ninterface ShaderBackgroundProps {\n  children: React.ReactNode\n}\n\nexport function ShaderBackground({ children }: ShaderBackgroundProps) {\n  const containerRef = useRef<HTMLDivElement>(null)\n  const [isActive, setIsActive] = useState(false)\n\n  useEffect(() => {\n    const handleMouseEnter = () => setIsActive(true)\n    const handleMouseLeave = () => setIsActive(false)\n\n    const container = containerRef.current\n    if (container) {\n      container.addEventListener(\"mouseenter\", handleMouseEnter)\n      container.addEventListener(\"mouseleave\", handleMouseLeave)\n    }\n\n    return () => {\n      if (container) {\n        container.removeEventListener(\"mouseenter\", handleMouseEnter)\n        container.removeEventListener(\"mouseleave\", handleMouseLeave)\n      }\n    }\n  }, [])\n\n  return (\n    <div ref={containerRef} className=\"min-h-[650px] w-full relative overflow-hidden\">\n      {/* SVG Filters */}\n      <svg className=\"absolute inset-0 w-0 h-0\">\n        <defs>\n          <filter id=\"glass-effect\" x=\"-50%\" y=\"-50%\" width=\"200%\" height=\"200%\">\n            <feTurbulence baseFrequency=\"0.005\" numOctaves=\"1\" result=\"noise\" />\n            <feDisplacementMap in=\"SourceGraphic\" in2=\"noise\" scale=\"0.3\" />\n            <feColorMatrix\n              type=\"matrix\"\n              values=\"1 0 0 0 0.02\n                      0 1 0 0 0.02\n                      0 0 1 0 0.05\n                      0 0 0 0.9 0\"\n              result=\"tint\"\n            />\n          </filter>\n          <filter id=\"gooey-filter\" x=\"-50%\" y=\"-50%\" width=\"200%\" height=\"200%\">\n            <feGaussianBlur in=\"SourceGraphic\" stdDeviation=\"4\" result=\"blur\" />\n            <feColorMatrix\n              in=\"blur\"\n              mode=\"matrix\"\n              values=\"1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9\"\n              result=\"gooey\"\n            />\n            <feComposite in=\"SourceGraphic\" in2=\"gooey\" operator=\"atop\" />\n          </filter>\n        </defs>\n      </svg>\n\n      {/* Background Shaders */}\n      <MeshGradient\n        className=\"absolute inset-0 w-full h-full\"\n        colors={[\"#000000\", \"#8b5cf6\", \"#ffffff\", \"#1e1b4b\", \"#4c1d95\"]}\n        speed={0.3}\n        backgroundColor=\"#000000\"\n      />\n      <MeshGradient\n        className=\"absolute inset-0 w-full h-full opacity-60\"\n        colors={[\"#000000\", \"#ffffff\", \"#8b5cf6\", \"#000000\"]}\n        speed={0.2}\n        wireframe=\"true\"\n        backgroundColor=\"transparent\"\n      />\n\n      {children}\n    </div>\n  )\n}\n","type":"registry:component"}]}
*/
"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { MeshGradient } from "@paper-design/shaders-react"

interface ShaderBackgroundProps {
  children: React.ReactNode
}

export function ShaderBackground({ children }: ShaderBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isActive, setIsActive] = useState(false)

  useEffect(() => {
    const handleMouseEnter = () => setIsActive(true)
    const handleMouseLeave = () => setIsActive(false)

    const container = containerRef.current
    if (container) {
      container.addEventListener("mouseenter", handleMouseEnter)
      container.addEventListener("mouseleave", handleMouseLeave)
    }

    return () => {
      if (container) {
        container.removeEventListener("mouseenter", handleMouseEnter)
        container.removeEventListener("mouseleave", handleMouseLeave)
      }
    }
  }, [])

  return (
    <div ref={containerRef} className="min-h-[650px] w-full relative overflow-hidden">
      {/* SVG Filters */}
      <svg className="absolute inset-0 w-0 h-0">
        <defs>
          <filter id="glass-effect" x="-50%" y="-50%" width="200%" height="200%">
            <feTurbulence baseFrequency="0.005" numOctaves="1" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="0.3" />
            <feColorMatrix
              type="matrix"
              values="1 0 0 0 0.02
                      0 1 0 0 0.02
                      0 0 1 0 0.05
                      0 0 0 0.9 0"
              result="tint"
            />
          </filter>
          <filter id="gooey-filter" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4" result="blur" />
            <feColorMatrix
              in="blur"
              mode="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9"
              result="gooey"
            />
            <feComposite in="SourceGraphic" in2="gooey" operator="atop" />
          </filter>
        </defs>
      </svg>

      {/* Background Shaders */}
      <MeshGradient
        className="absolute inset-0 w-full h-full"
        colors={["#000000", "#8b5cf6", "#ffffff", "#1e1b4b", "#4c1d95"]}
        speed={0.3}
        backgroundColor="#000000"
      />
      <MeshGradient
        className="absolute inset-0 w-full h-full opacity-60"
        colors={["#000000", "#ffffff", "#8b5cf6", "#000000"]}
        speed={0.2}
        wireframe="true"
        backgroundColor="transparent"
      />

      {children}
    </div>
  )
}
