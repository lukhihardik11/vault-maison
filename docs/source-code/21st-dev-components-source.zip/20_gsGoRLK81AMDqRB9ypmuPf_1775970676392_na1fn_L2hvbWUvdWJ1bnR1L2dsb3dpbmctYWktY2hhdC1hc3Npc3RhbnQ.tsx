import React, { useState, useRef, useEffect } from 'react';
import { Paperclip, Link, Code, Mic, Send, Info, Bot, X } from 'lucide-react';

const FloatingAiAssistant = () => {\
  const [isChatOpen, setIsChatOpen] = useState(false);\
  const [message, setMessage] = useState('');\
  const [charCount, setCharCount] = useState(0);\
  const maxChars = 2000;\
  const chatRef = useRef(null);\
  \
  const handleInputChange = (e) => {\
    const value = e.target.value;\
    setMessage(value);\
    setCharCount(value.length);\
  };\
\
  const handleSend = () => {\
    if (message.trim()) {\
      console.log('Sending message:', message);\
      setMessage('');\
      setCharCount(0);\
    }\
  };\
\
  const handleKeyDown = (e) => {\
    if (e.key === 'Enter' && !e.shiftKey) {\
      e.preventDefault();\
      handleSend();\
    }\
  };\
\
  // Close chat when clicking outside\
  useEffect(() => {\
    const handleClickOutside = (event) => {\
      if (chatRef.current && !chatRef.current.contains(event.target)) {\
        // Check if the click is not on the floating button\
        if (!event.target.closest('.floating-ai-button')) {\
          setIsChatOpen(false);\
        }\
      }\
    };\
\
    document.addEventListener('mousedown', handleClickOutside);\
    return () => {\
      document.removeEventListener('mousedown', handleClickOutside);\
    };\
  }, []);\
\
  return (\
    <div className=\"fixed bottom-6 right-6 z-50\">\
      {/* Floating 3D Glowing AI Logo */}\
      <button \
        className={`floating-ai-button relative w-16 h-16 rounded-full flex items-center justify-center transition-all duration-500 transform ${\
          isChatOpen ? 'rotate-90' : 'rotate-0'\
        }`}\
        onClick={() => setIsChatOpen(!isChatOpen)}\
        style={{\
          background: 'linear-gradient(135deg, rgba(99,102,241,0.8) 0%, rgba(168,85,247,0.8) 100%)',\
          boxShadow: '0 0 20px rgba(139, 92, 246, 0.7), 0 0 40px rgba(124, 58, 237, 0.5), 0 0 60px rgba(109, 40, 217, 0.3)',\
          border: '2px solid rgba(255, 255, 255, 0.2)',\
        }}\
      >\
        {/* 3D effect */}\
        <div className=\"absolute inset-0 rounded-full bg-gradient-to-b from-white/20 to-transparent opacity-30\"></div>\
        \
        {/* Inner glow */}\
        <div className=\"absolute inset-0 rounded-full border-2 border-white/10\"></div>\
        \
        {/* AI Icon */}\
        <div className=\"relative z-10\">\
        { isChatOpen ? <X /> :  <Bot className=\"w-8 h-8 text-white\" />}\
        </div>\
        \
        {/* Glowing animation */}\
        <div className=\"absolute inset-0 rounded-full animate-ping opacity-20 bg-indigo-500\"></div>\
      </button>\
\
      {/* Chat Interface */}\
      {isChatOpen && (\
        <div \
          ref={chatRef}\
          className=\"absolute bottom-20 right-0 w-max max-w-[500px] transition-all duration-300 origin-bottom-right\"\
          style={{\
            animation: 'popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards',\
          }}\
        >\
          <div className=\"relative flex flex-col rounded-3xl bg-gradient-to-br from-zinc-800/80 to-zinc-900/90 border border-zinc-500/50 shadow-2xl backdrop-blur-3xl overflow-hidden\">\
            \
            {/* Header */}\
            <div className=\"flex items-center justify-between px-6 pt-4 pb-2\">\
              <div className=\"flex items-center gap-1.5\">\
                <div className=\"w-2 h-2 rounded-full bg-green-500 animate-pulse\"></div>\
                <span className=\"text-xs font-medium text-zinc-400\">AI Assistant</span>\
              </div>\
              <div className=\"flex items-center gap-2\">\
                <span className=\"px-2 py-1 text-xs font-medium bg-zinc-800/60 text-zinc-300 rounded-2xl\">\
                  GPT-4\
                </span>\
                <span className=\"px-2 py-1 text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/20 rounded-2xl\">\
                  Pro\
                </span>\
                <button \
                  onClick={() => setIsChatOpen(false)}\
                  className=\"p-1.5 rounded-full hover:bg-zinc-700/50 transition-colors\"\
                >\
                  <X className=\"w-4 h-4 text-zinc-400\" />\
                </button>\
              </div>\
            </div>\
\
            {/* Input Section */}\
            <div className=\"relative overflow-hidden\">\
              <textarea\
                value={message}\
                onChange={handleInputChange}\
                onKeyDown={handleKeyDown}\
                rows={4}\
                className=\"w-full px-6 py-4 bg-transparent border-none outline-none resize-none text-base font-normal leading-relaxed min-h-[120px] text-zinc-100 placeholder-zinc-500 scrollbar-none\"\
                placeholder=\"What would you like to explore today? Ask anything, share ideas, or request assistance...\"\
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}\
              />\
              <div \
                className=\"absolute inset-0 bg-gradient-to-t from-zinc-800/5 to-transparent pointer-events-none\"\
                style={{ background: 'linear-gradient(to top, rgba(39, 39, 42, 0.05), transparent)' }}\
              ></div>\
            </div>\
\
            {/* Controls Section */}\
            <div className=\"px-4 pb-4\">\
              <div className=\"flex items-center justify-between\">\
                <div className=\"flex items-center gap-2\">\
                  {/* Attachment Group */}\
                  <div className=\"flex items-center gap-1.5 p-1 bg-zinc-800/40 rounded-xl border border-zinc-700/50\">\
                    {/* File Upload */}\
                    <button className=\"group relative p-2.5 bg-transparent border-none rounded-lg cursor-pointer transition-all duration-300 text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/80 hover:scale-105 hover:-rotate-3 transform\">\
                      <Paperclip className=\"w-4 h-4 transition-all duration-300 group-hover:scale-125 group-hover:-rotate-12\" />\
                      <div className=\"absolute -top-10 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-zinc-900/95 text-zinc-200 text-xs rounded-lg whitespace-nowrap opacity-0 transition-all duration-300 pointer-events-none group-hover:opacity-100 group-hover:-translate-y-1 shadow-lg border border-zinc-700/50 backdrop-blur-sm\">\
                        Upload files\
                        <div className=\"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-zinc-900/95\"></div>\
                      </div>\
                    </button>\
\
                    {/* Link */}\
                    <button className=\"group relative p-2.5 bg-transparent border-none rounded-lg cursor-pointer transition-all duration-300 text-zinc-500 hover:text-red-400 hover:bg-zinc-800/80 hover:scale-105 hover:rotate-6 transform\">\
                      <Link className=\"w-4 h-4 transition-all duration-300 group-hover:scale-125 group-hover:rotate-12\" />\
                      <div className=\"absolute -top-10 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-zinc-900/95 text-zinc-200 text-xs rounded-lg whitespace-nowrap opacity-0 transition-all duration-300 pointer-events-none group-hover:opacity-100 group-hover:-translate-y-1 shadow-lg border border-zinc-700/50 backdrop-blur-sm\">\
                        Web link\
                        <div className=\"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-zinc-900/95\"></div>\
                      </div>\
                    </button>\
\
                    {/* Code */}\
                    <button className=\"group relative p-2.5 bg-transparent border-none rounded-lg cursor-pointer transition-all duration-300 text-zinc-500 hover:text-green-400 hover:bg-zinc-800/80 hover:scale-105 hover:rotate-3 transform\">\
                      <Code className=\"w-4 h-4 transition-all duration-300 group-hover:scale-125 group-hover:-rotate-6\" />\
                      <div className=\"absolute -top-10 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-zinc-900/95 text-zinc-200 text-xs rounded-lg whitespace-nowrap opacity-0 transition-all duration-300 pointer-events-none group-hover:opacity-100 group-hover:-translate-y-1 shadow-lg border border-zinc-700/50 backdrop-blur-sm\">\
                        Code repo\
                        <div className=\"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-zinc-900/95\"></div>\
                      </div>\
                    </button>\
\
                    {/* Design (Figma icon) */}\
                    <button className=\"group relative p-2.5 bg-transparent border-none rounded-lg cursor-pointer transition-all duration-300 text-zinc-500 hover:text-purple-400 hover:bg-zinc-800/80 hover:scale-105 hover:-rotate-6 transform\">\
                      <svg className=\"w-4 h-4 transition-all duration-300 group-hover:scale-125 group-hover:rotate-12\" viewBox=\"0 0 24 24\" fill=\"currentColor\">\
                        <path d=\"M15.852 8.981h-4.588V0h4.588c2.476 0 4.49 2.014 4.49 4.49S18.328 8.98 15.852 8.981zm-4.587-7.51h3.117c1.665 0 3.019-1.355 3.019-3.019S14.382 0 12.735 0h-3.117v1.471zm0 1.471H8.148c-2.476 0-4.49-2.015-4.49-4.49S5.672 0 8.148 0h4.588v8.981zm-4.587-7.51c-1.665 0-3.019 1.355-3.019 3.019S.566 6.038 2.23 6.038h3.117V1.471H.758zM8.148 15.019c-2.476 0-4.49 2.014-4.49 4.49s2.014 4.49 4.49 4.49h4.588v-8.98H8.148zm-3.019 1.471c-1.665 0-3.019 1.355-3.019 3.019s1.354 3.019 3.019 3.019h3.117v-6.038H5.129zm7.704 0c-2.476 0-4.49 2.015-4.49 4.49s2.014 4.49 4.49 4.49 4.49-2.015 4.49-4.49-2.014-4.49-4.49-4.49zm0 7.509c-1.665 0-3.019-1.355-3.019-3.019s1.354-3.019 3.019-3.019 3.019 1.354 3.019 3.019-1.354 3.019-3.019 3.019zM8.148 24c-2.476 0-4.49-2.015-4.49-4.49s2.014-4.49 4.49-4.49h4.588V24H8.148zm3.117-1.471V16.49H8.148c-1.665 0-3.019 1.355-3.019 3.019s1.354 3.019 3.019 3.019h3.117z\"/>\
                      </svg>\
                      <div className=\"absolute -top-10 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-zinc-900/95 text-zinc-200 text-xs rounded-lg whitespace-nowrap opacity-0 transition-all duration-300 pointer-events-none group-hover:opacity-100 group-hover:-translate-y-1 shadow-lg border border-zinc-700/50 backdrop-blur-sm\">\
                        Design\
                        <div className=\"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-zinc-900/95\"></div>\
                      </div>\
                    </button>\
                  </div>\
                </div>\
\
                <div className=\"flex items-center gap-2\">\
                  {/* Character Count */}\
                  <span className=\"text-xs font-medium text-zinc-500\">{charCount}/{maxChars}</span>\
\
                  {/* Send Button */}\
                  <button \
                    onClick={handleSend}\
                    className=\"group relative flex items-center justify-center w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full border-2 border-transparent transition-all duration-300 hover:border-purple-400/50 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-purple-500/50\"\
                    disabled={!message.trim()}\
                  >\
                    <Send className=\"w-5 h-5 text-white transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-12\" />\
                    <div className=\"absolute -top-12 left-1/2 transform -translate-x-1/2 px-4 py-2 bg-zinc-900/95 text-zinc-200 text-sm rounded-lg whitespace-nowrap opacity-0 transition-all duration-300 pointer-events-none group-hover:opacity-100 group-hover:-translate-y-2 shadow-lg border border-zinc-700/50 backdrop-blur-sm\">\
                      Send message\
                      <div className=\"absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-zinc-900/95\"></div>\
                    </div>\
                  </button>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      )}\
    </div>\
  );\
};\
\
export default FloatingAiAssistant;\
