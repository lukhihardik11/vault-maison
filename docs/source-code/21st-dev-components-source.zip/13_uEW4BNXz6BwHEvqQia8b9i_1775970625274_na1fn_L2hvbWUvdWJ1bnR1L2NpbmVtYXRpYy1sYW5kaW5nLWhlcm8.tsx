
// src/components/ui/cinematic-hero.tsx
"use client";

import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { cn } from "@/lib/utils";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const INJECTED_STYLES = `
  .gsap-reveal { visibility: hidden; }

  /* Environment Overlays */
  .film-grain {
      position: absolute; inset: 0; width: 100%; height: 100%;
      pointer-events: none; z-index: 50; opacity: 0.05; mix-blend-mode: overlay;
      background: url('data:image/svg+xml;utf8,<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\\"><filter id=\"noiseFilter\\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.8\" numOctaves=\"3\" stitchTiles=\"stitch\\"/></filter><rect width=\"100%\" height=\"100%\" filter=\"url(%23noiseFilter)\"/></svg>');
  }

  .bg-grid-theme {
      background-size: 60px 60px;
      background-image: \
          linear-gradient(to right, color-mix(in srgb, var(--color-foreground) 5%, transparent) 1px, transparent 1px),\
          linear-gradient(to bottom, color-mix(in srgb, var(--color-foreground) 5%, transparent) 1px, transparent 1px);\
      mask-image: radial-gradient(ellipse at center, black 0%, transparent 70%);\
      -webkit-mask-image: radial-gradient(ellipse at center, black 0%, transparent 70%);
  }

  /* -------------------------------------------------------------------
     PHYSICAL SKEUOMORPHIC MATERIALS (Restored 3D Depth)
  ---------------------------------------------------------------------- */
  
  /* OUTSIDE THE CARD: Theme-aware text (Shadow in Light Mode, Glow in Dark Mode) */
  .text-3d-matte {
      color: var(--color-foreground);
      text-shadow: \
          0 10px 30px color-mix(in srgb, var(--color-foreground) 20%, transparent), \
          0 2px 4px color-mix(in srgb, var(--color-foreground) 10%, transparent);
  }

  .text-silver-matte {
      background: linear-gradient(180deg, var(--color-foreground) 0%, color-mix(in srgb, var(--color-foreground) 40%, transparent) 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      transform: translateZ(0); /* Hardware acceleration to prevent WebKit clipping bug */
      filter: \
          drop-shadow(0px 10px 20px color-mix(in srgb, var(--color-foreground) 15%, transparent)) \
          drop-shadow(0px 2px 4px color-mix(in srgb, var(--color-foreground) 10%, transparent));
  }

  /* INSIDE THE CARD: Hardcoded Silver/White for the dark background, deep rich shadows */
  .text-card-silver-matte {
      background: linear-gradient(180deg, #FFFFFF 0%, #A1A1AA 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      transform: translateZ(0);
      filter: \
          drop-shadow(0px 12px 24px rgba(0,0,0,0.8)) \
          drop-shadow(0px 4px 8px rgba(0,0,0,0.6));
  }

  /* Deep Physical Card with Dynamic Mouse Lighting */
  .premium-depth-card {
      background: linear-gradient(145deg, #162C6D 0%, #0A101D 100%);
      box-shadow: \
          0 40px 100px -20px rgba(0, 0, 0, 0.9),\
          0 20px 40px -20px rgba(0, 0, 0, 0.8),\
          inset 0 1px 2px rgba(255, 255, 255, 0.2),\
          inset 0 -2px 4px rgba(0, 0, 0, 0.8);\
      border: 1px solid rgba(255, 255, 255, 0.04);
      position: relative;
  }

  .card-sheen {
      position: absolute; inset: 0; border-radius: inherit; pointer-events: none; z-index: 50;
      background: radial-gradient(800px circle at var(--mouse-x, 50%) var(--mouse-y, 50%), rgba(255,255,255,0.06) 0%, transparent 40%);
      mix-blend-mode: screen; transition: opacity 0.3s ease;
  }

  /* Realistic iPhone Mockup Hardware */
  .iphone-bezel {
      background-color: #111;
      box-shadow: \
          inset 0 0 0 2px #52525B, \
          inset 0 0 0 7px #000, \
          0 40px 80px -15px rgba(0,0,0,0.9),\
          0 15px 25px -5px rgba(0,0,0,0.7);
      transform-style: preserve-3d;
  }

  .hardware-btn {
      background: linear-gradient(90deg, #404040 0%, #171717 100%);
      box-shadow: \
          -2px 0 5px rgba(0,0,0,0.8),\
          inset -1px 0 1px rgba(255,255,255,0.15),\
          inset 1px 0 2px rgba(0,0,0,0.8);\
      border-left: 1px solid rgba(255,255,255,0.05);
  }
  
  .screen-glare {
      background: linear-gradient(110deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0) 45%);
  }

  .widget-depth {
      background: linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.01) 100%);
      box-shadow: \
          0 10px 20px rgba(0,0,0,0.3),\
          inset 0 1px 1px rgba(255,255,255,0.05),\
          inset 0 -1px 1px rgba(0,0,0,0.5);\
      border: 1px solid rgba(255,255,255,0.03);
  }

  .floating-ui-badge {
      background: linear-gradient(135deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0.01) 100%);
      backdrop-filter: blur(24px); \
      -webkit-backdrop-filter: blur(24px);
      box-shadow: \
          0 0 0 1px rgba(255, 255, 255, 0.1),\
          0 25px 50px -12px rgba(0, 0, 0, 0.8),\
          inset 0 1px 1px rgba(255,255,255,0.2),\
          inset 0 -1px 1px rgba(0,0,0,0.5);
  }

  /* Physical Tactile Buttons */
  .btn-modern-light, .btn-modern-dark {
      transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
  }
  .btn-modern-light {
      background: linear-gradient(180deg, #FFFFFF 0%, #F1F5F9 100%);
      color: #0F172A;
      box-shadow: 0 0 0 1px rgba(0,0,0,0.05), 0 2px 4px rgba(0,0,0,0.1), 0 12px 24px -4px rgba(0,0,0,0.3), inset 0 1px 1px rgba(255,255,255,1), inset 0 -3px 6px rgba(0,0,0,0.06);
  }
  .btn-modern-light:hover {
      transform: translateY(-3px);
      box-shadow: 0 0 0 1px rgba(0,0,0,0.05), 0 6px 12px -2px rgba(0,0,0,0.15), 0 20px 32px -6px rgba(0,0,0,0.4), inset 0 1px 1px rgba(255,255,255,1), inset 0 -3px 6px rgba(0,0,0,0.06);
  }
  .btn-modern-light:active {
      transform: translateY(1px);
      background: linear-gradient(180deg, #F1F5F9 0%, #E2E8F0 100%);
      box-shadow: 0 0 0 1px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.1), inset 0 3px 6px rgba(0,0,0,0.1), inset 0 0 0 1px rgba(0,0,0,0.02);
  }
  .btn-modern-dark {
      background: linear-gradient(180deg, #27272A 0%, #18181B 100%);
      color: #FFFFFF;
      box-shadow: 0 0 0 1px rgba(255,255,255,0.1), 0 2px 4px rgba(0,0,0,0.6), 0 12px 24px -4px rgba(0,0,0,0.9), inset 0 1px 1px rgba(255,255,255,0.15), inset 0 -3px 6px rgba(0,0,0,0.8);
  }
  .btn-modern-dark:hover {
      transform: translateY(-3px);
      background: linear-gradient(180deg, #3F3F46 0%, #27272A 100%);
      box-shadow: 0 0 0 1px rgba(255,255,255,0.15), 0 6px 12px -2px rgba(0,0,0,0.7), 0 20px 32px -6px rgba(0,0,0,1), inset 0 1px 1px rgba(255,255,255,0.2), inset 0 -3px 6px rgba(0,0,0,0.8);
  }
  .btn-modern-dark:active {
      transform: translateY(1px);
      background: #18181B;
      box-shadow: 0 0 0 1px rgba(255,255,255,0.05), inset 0 3px 8px rgba(0,0,0,0.9), inset 0 0 0 1px rgba(0,0,0,0.5);
  }

  .progress-ring {
      transform: rotate(-90deg);
      transform-origin: center;
      stroke-dasharray: 402;
      stroke-dashoffset: 402;
      stroke-linecap: round;
  }
`;

export interface CinematicHeroProps extends React.HTMLAttributes<HTMLDivElement> {
  brandName?: string;
  tagline1?: string;
  tagline2?: string;
  cardHeading?: string;
  cardDescription?: React.ReactNode;
  metricValue?: number;
  metricLabel?: string;
  ctaHeading?: string;
  ctaDescription?: string;
}

export function CinematicHero({
  brandName = "Sobers",
  tagline1 = "Track the journey,",
  tagline2 = "not just the days.",
  cardHeading = "Accountability, redefined.",
  cardDescription = <><span className="text-white font-semibold">Sobers</span> empowers sponsors and sponsees in 12-step recovery programs with structured accountability, precise sobriety tracking, and beautiful visual timelines.</>,
  metricValue = 365,
  metricLabel = "Days Sober",
  ctaHeading = "Start your recovery.",
  ctaDescription = "Join thousands of others in the 12-step program and take control of your timeline today.",
  className,
  ...props
}: CinematicHeroProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mainCardRef = useRef<HTMLDivElement>(null);
  const mockupRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number>(0);

  // 1. High-Performance Mouse Interaction Logic (Using requestAnimationFrame)
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (window.scrollY > window.innerHeight * 2) return;

      cancelAnimationFrame(requestRef.current);
      requestRef.current = requestAnimationFrame(() => {
        if (mainCardRef.current && mockupRef.current) {
          const rect = mainCardRef.current.getBoundingClientRect();
          const mouseX = e.clientX - rect.left;
          const mouseY = e.clientY - rect.top;

          mainCardRef.current.style.setProperty("--mouse-x", `${mouseX}px`);
          mainCardRef.current.style.setProperty("--mouse-y", `${mouseY}px`);

          const xVal = (e.clientX / window.innerWidth - 0.5) * 2;
          const yVal = (e.clientY / window.innerHeight - 0.5) * 2;

          gsap.to(mockupRef.current, {
            rotationY: xVal * 12,
            rotationX: -yVal * 12,
            ease: "power3.out",
            duration: 1.2,
          });
        }
      });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      cancelAnimationFrame(requestRef.current);
    };
  }, []);

  // 2. Complex Cinematic Scroll Timeline
  useEffect(() => {
    const isMobile = window.innerWidth < 768;

    const ctx = gsap.context(() => {
      gsap.set(".text-track", { autoAlpha: 0, y: 60, scale: 0.85, filter: "blur(20px)", rotationX: -20 });
      gsap.set(".text-days", { autoAlpha: 1, clipPath: 'inset(0 100% 0 0)' });
      gsap.set(".main-card", { y: isMobile ? 0 : window.innerHeight * 0.2, scale: isMobile ? 1 : 0.8, transformOrigin: "center" });
      gsap.set(".card-left-text", { autoAlpha: 0 });
      gsap.set(".card-right-text", { autoAlpha: 0 });
      gsap.set(".progress-ring", { strokeDashoffset: 402 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: containerRef.current,
          start: "top top",
          end: "+=3000",
          scrub: 1,
          pin: true,
        },
      });

      tl.to(".text-track", { autoAlpha: 1, y: 0, scale: 1, filter: "blur(0px)", rotationX: 0, duration: 2, ease: "power2.out" })
        .to(".text-days", { clipPath: 'inset(0 0% 0 0)', duration: 2, ease: "power2.inOut" }, "-=.5")
        .to(".main-card", { y: 0, scale: 1, duration: 3, ease: "power3.inOut" }, "<+=1")
        .to(".card-left-text", { autoAlpha: 1, duration: 2, ease: "power2.out" }, "-=.5")
        .to(".card-right-text", { autoAlpha: 1, duration: 2, ease: "power2.out" }, "<")
        .to(".progress-ring", { strokeDashoffset: 0, duration: 3, ease: "power2.inOut" }, "<");
    });

    return () => ctx.revert();
  }, []);

  return (
    <div ref={containerRef} className={cn("relative w-full text-white", className)} {...props}>
      <style>{INJECTED_STYLES}</style>
      <div className="relative h-screen w-full">
        <div className="text-track absolute inset-0 flex flex-col items-center justify-center space-y-4">
          <h1 className="text-6xl font-bold">{tagline1}</h1>
          <h2 className="text-6xl font-bold">{tagline2}</h2>
        </div>
      </div>
      <div className="main-card relative mx-auto -mt-[50vh] mb-[50vh] h-[80vh] w-[90vw] max-w-6xl rounded-3xl">
        <div ref={mainCardRef} className="premium-depth-card relative h-full w-full rounded-3xl p-8">
          <div className="card-sheen" />
          <div className="relative z-10 flex h-full w-full flex-col lg:flex-row">
            <div className="card-left-text flex flex-1 flex-col justify-center space-y-6 p-8 text-center lg:text-left">
              <span className="text-sm font-semibold uppercase tracking-widest text-blue-300">{brandName}</span>
              <h3 className="text-4xl font-bold leading-tight text-white">{cardHeading}</h3>
              <p className="text-lg text-gray-300">
                {cardDescription}
              </p>
            </div>
            <div className="card-right-text flex flex-1 flex-col items-center justify-center space-y-8 p-8">
              <div ref={mockupRef} className="iphone-bezel relative h-[500px] w-[250px] rounded-[40px] p-2">
                <div className="hardware-btn absolute -left-1 top-24 h-16 w-1 rounded-l-sm" />
                <div className="hardware-btn absolute -left-1 top-44 h-16 w-1 rounded-l-sm" />
                <div className="hardware-btn absolute -right-1 top-32 h-24 w-1 rounded-r-sm" />
                <div className="screen-glare absolute inset-0 z-20 h-full w-full rounded-[32px]" />
                <div className="relative z-10 h-full w-full overflow-hidden rounded-[32px] bg-black">
                  <img src="/placeholder.svg" alt="App Screenshot" className="h-full w-full object-cover" />
                </div>
              </div>
              <div className="text-center">
                <p className="text-lg font-medium text-gray-300">{ctaHeading}</p>
                <p className="text-sm text-gray-400">{ctaDescription}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="relative h-screen w-full">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-days text-center">
            <p className="text-9xl font-bold">{metricValue}</p>
            <p className="text-2xl font-medium text-gray-400">{metricLabel}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
