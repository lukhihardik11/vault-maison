export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  images: Image[];
  price: number;
  sku: string;
  stock: number;
  collections: Collection[];
  concept: Concept;
  materials: Material[];
  gemstones: Gemstone[];
  relatedProducts: Product[];
}

export interface Collection {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: Image;
  products: Product[];
}

export interface Concept {
  id: string;
  name: string;
  slug: string;
  description: string;
  heroImage: Image;
  products: Product[];
  collections: Collection[];
}

export interface Image {
  url: string;
  alt: string;
}

export interface Material {
  id: string;
  name: string;
}

export interface Gemstone {
  id: string;
  name: string;
  shape: string;
  carat: number;
}
import { Product, Collection, Concept } from './types';

const API_URL = process.env.GRAPHQL_API_URL!;
const API_TOKEN = process.env.GRAPHQL_API_TOKEN!;

async function fetchAPI(query: string, { variables }: { variables?: any } = {}) {
  const headers = { 'Content-Type': 'application/json' };

  if (API_TOKEN) {
    headers['Authorization'] = `Bearer ${API_TOKEN}`;
  }

  const res = await fetch(API_URL, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      query,
      variables,
    }),
  });

  const json = await res.json();
  if (json.errors) {
    console.error(json.errors);
    throw new Error('Failed to fetch API');
  }

  return json.data;
}

export async function getAllProducts(): Promise<Product[]> {
  const data = await fetchAPI(`
    query {
      products {
        id
        name
        slug
        price
        images {
          url
          alt
        }
      }
    }
  `);
  return data.products;
}
