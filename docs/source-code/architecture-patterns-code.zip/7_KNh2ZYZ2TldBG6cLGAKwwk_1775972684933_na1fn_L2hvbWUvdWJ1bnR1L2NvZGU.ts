/**
 * i18n-config.ts
 */
export const i18n = {
  defaultLocale: 'en',
  locales: ['en', 'de', 'cs'],
} as const;

export type Locale = (typeof i18n)['locales'][number];

/**
 * middleware.ts
 */
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { match as matchLocale } from '@formatjs/intl-localematcher';
import Negotiator from 'negotiator';

function getLocale(request: NextRequest): string | undefined {
  const negotiatorHeaders: Record<string, string> = {};
  request.headers.forEach((value, key) => (negotiatorHeaders[key] = value));

  // @ts-ignore locales are readonly
  const locales: string[] = i18n.locales;

  let languages = new Negotiator({ headers: negotiatorHeaders }).languages();

  const locale = matchLocale(languages, locales, i18n.defaultLocale);
  return locale;
}

export function middleware(request: NextRequest) {
  const pathname = request.nextUrl.pathname;

  if (
    [
      '/manifest.json',
      '/favicon.ico',
      '/next.svg',
      '/vercel.svg',
    ].includes(pathname)
  ) return

  const pathnameIsMissingLocale = i18n.locales.every(
    (locale) => !pathname.startsWith(`/${locale}/`) && pathname !== `/${locale}`
  );

  if (pathnameIsMissingLocale) {
    const locale = getLocale(request);

    return NextResponse.redirect(
      new URL(`/${locale}/${pathname}`, request.url)
    );
  }
}

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico).*)"',
  ],
};

/**
 * dictionaries/en.json
 */
{
  "products": {
    "cart": "Add to Cart"
  },
  "navigation": {
    "home": "Home",
    "about": "About"
  }
}

/**
 * dictionaries/de.json
 */
{
  "products": {
    "cart": "In den Warenkorb legen"
  },
  "navigation": {
    "home": "Startseite",
    "about": "Über uns"
  }
}

/**
 * get-dictionary.ts
 */
import "server-only";

const dictionaries = {
  en: () => import("./dictionaries/en.json").then((module) => module.default),
  de: () => import("./dictionaries/de.json").then((module) => module.default),
};

export const getDictionary = async (locale: Locale) => dictionaries[locale]();

/**
 * app.tsx
 */
import { getDictionary } from "./get-dictionary";

export default async function Home({params: { lang },}: {
  params: { lang: Locale };
}) {
  const dictionary = await getDictionary(lang);
  return (
    <div>
      <nav>
        <ul>
          <li>{dictionary.navigation.home}</li>
          <li>{dictionary.navigation.about}</li>
        </ul>
      </nav>
      <main>
        <h1>{dictionary.products.cart}</h1>
      </main>
    </div>
  );
}
